
The extras module contains functionality that is not often used. It holds
following functionality:

 - block region: add regions which will be exposed as blocks.
 - extra fields: expose extra fields defined by other modules.
 - field permissions: add view permissions on DS fields.
 - hidden region: region which in case it has fields will not be printed.
 - switch view mode field: switch from one view mode to another inline.

Any other functionality will be included in this module.
