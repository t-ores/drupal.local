<?php

/**
 * @file
 * Post update functions for Features.
 */

/**
 * Clear caches due to changes in service arguments.
 */
function features_post_update_d9_compatibility() {
  // Empty post-update hook.
}

/**
 * Clear caches due to changes in features_assigner service arguments.
 */
function features_post_update_features_assigner_args() {
  // Empty post-update hook.
}

/**
 * Clear caches due to changes in features.manager service arguments.
 */
function features_post_update_prefixed_dependencies() {
  // Empty post-update hook.
}
