<?php

namespace Drupal\features\Exception;

/**
 * {@inheritDoc}
 */
class InvalidArgumentException extends \InvalidArgumentException {

}
