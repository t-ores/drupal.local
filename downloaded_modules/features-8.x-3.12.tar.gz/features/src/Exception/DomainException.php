<?php

namespace Drupal\features\Exception;

/**
 * {@inheritDoc}
 */
class DomainException extends \DomainException {

}
