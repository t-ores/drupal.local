# owl
OWL Carousel for Drupal 8
+ Field formatter: See video: https://www.youtube.com/watch?v=PzBMJqkNHQ0
+ Views integrated see video: https://www.youtube.com/watch?v=kKps02rc3pE

# Credits
Nicholas James [swim](https://www.drupal.org/u/swim)  
Anish Sheela [anisha](https://www.drupal.org/u/anisha)   
Nicolas Borda [ipwa](https://www.drupal.org/u/ipwa)  
Alex Burrows [aburrows](https://www.drupal.org/u/aburrows)  
Julian Pustkuchen [Anybody](https://www.drupal.org/u/anybody)  
