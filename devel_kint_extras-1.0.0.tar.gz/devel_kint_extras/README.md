# Devel Kint Extras

Thank you for downloading Devel Kint Extras. This module offers to display methods and statics available for an object when using Kint with Devel.

## Installation

The recommended method for installation is via Composer.

## Configuration

Just go to admin/config/development/devel and select Kint Extended as Variables Dumper.
